start cli.exe skey.txt
